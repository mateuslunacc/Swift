//
//  FilmeTableViewCell.swift
//  DesafioCoreData
//
//  Created by Francini Roberta de Carvalho on 11/1/16.
//  Copyright © 2016 Francini Carvalho. All rights reserved.
//

import UIKit

class FilmeTableViewCell: UITableViewCell {

   

}
