//
//  ViewController.swift
//  ExemploPickerView
//
//  Created by Tiago - Eldorado on 12/12/16.
//  Copyright © 2016 Tiago - Eldorado. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController {
    
    // Opções da Picker View
    let nomes = ["Tiago", "Lucas", "Wislas", "Marcelo", "Gustavo", "Diego", "Yuri"]
    
    // Outlet para a label que usamos para testar
    @IBOutlet weak var pickerViewLabel: UILabel! {
        didSet {
            pickerViewLabel.text = "Nome selecionado: \(nomeSelecionado)"
        }
    }
    
    // Outlet para a Picker View
    @IBOutlet weak var pickerView: UIPickerView! {
        didSet {
            // Definimos que os métodos de Data Source e Delegate do Picker View foram implementados pela nossa classe
            pickerView.dataSource = self
            pickerView.delegate = self
        }
    }
    
    // Retorna o valor do componente selecionado na Picker View
    var nomeSelecionado: String {
        get {
            // Com o selectedRow(inComponent:) é possível saber qual
            // linha o usuário escolheu na Picker View
            return nomes[pickerView.selectedRow(inComponent: 0)]
        }
    }
    
    // MARK: - Date Picker
    
    @IBOutlet weak var datePickerLabel: UILabel! {
        didSet {
            datePickerLabel.text = "Data selecionada: \(dataSelecionada)"
        }
    }
    
    @IBOutlet weak var datePicker: UIDatePicker!
    
    // Propriedade que retorna a data selecionada no datePicker em forma de String
    var dataSelecionada: String {
        get {
            // DateFormatter é utilizado para formatar Date em String com base em um formato predefinido
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd/MM/yy hh:mm:ss "
            
            // Pega o valor NSDate que está selecionado no Date Picker
            let dia = datePicker.date
            
            // Converte para String
            return dateFormatter.string(from: dia)
        }
    }

    @IBAction func datePickerValueChanged(_ sender: Any) {
        datePickerLabel.text = "Data selecionada: \(dataSelecionada)"
    }
}

// MARK: -
// Aqui estamos implementando os protocolos UIPickerViewDataSource e UIPickerViewDelegate
extension ViewController: UIPickerViewDataSource, UIPickerViewDelegate {
    // MARK: Picker View Data Source
    // Quantas colunas a Picker View deve ter?
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // Quantas linhas tem em cada coluna?
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return nomes.count
    }
    
    // MARK: - Picker View Delegate
    // Qual texto vai aparecer em cada linha na coluna?
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return nomes[row]
    }
    
    // O que vai acontecer quando o usuário selecionar uma coluna?
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        print(nomeSelecionado)
        
        pickerViewLabel.text = "Nome selecionado: \(nomeSelecionado)"
    }
    
}
