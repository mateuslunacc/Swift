//
//  MenusViewController.swift
//  ExemploCollectionView
//
//  Created by Tiago - Eldorado on 12/12/16.
//  Copyright © 2016 Tiago - Eldorado. All rights reserved.
//

import UIKit

/*
 No Storyboard:
 - Adicione um componente Collection View na sua View Controller
 - Defina a classe da célula como a classe que você criou (LocalCollectionViewCell nesse exemplo)
 - Crie os outlets da célula na classe
 - Defina o atributo identifier da célula (localCellIdentifier nesse exemplo)
 - Em Collection View Flow Layout defina o atributo Scroll Direction como Horizontal
 */


class MenusViewController: UIViewController {
    // 1. Uma forma de armazenar as strings utilizadas no storyboard
    // é criar uma estrutura para armazená-las, evitando "números mágicos"
    struct Storyboard {
        static let cellIdentifier = "localCellIdentifier"
    }
    
    // 2. Array com os locais a serem mostrados
    // Ou seja, o local onde seus dados estarão armazenados
    var locais: [Local] {
        // Como eu só implementei o get, ela é read-only
        get {
            return Local.getList()
        }
    }
    
    // 3. Outlet para a CollectionView na interface
    @IBOutlet weak var horizontalCollectionView: UICollectionView! {
        // Quando ela for instanciada
        didSet {
            // Definimos o delegate e datasource como a nossa classe
            horizontalCollectionView.delegate = self
            horizontalCollectionView.dataSource  = self
        }
    }
}

// 4. Implementamos o delegate e datasource da CollectionView
extension MenusViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    // 4.1 Número de sessões da CollectionView
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    // 4.2 Número de itens na CollectionView
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return locais.count
    }
    
    // 4.3 Função para configurar os itens da CollectionView
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: Storyboard.cellIdentifier, for: indexPath)
        
        // Aqui só estamos deixando os cantos da célula arredondados
        cell.layer.cornerRadius = 10.0
        cell.layer.masksToBounds = true
        
        // Convertemos a cell para uma TextCollectionViewCell
        // Caso seja possível converter, definimos as informações que ela mostra
        if let localCell = cell as? LocalCollectionViewCell {
            // Pegamos a informação relacionada à célula
            let local = locais[indexPath.row]
            
            // Definimos as informações na célula
            localCell.local = local
            localCell.localImageView.image = UIImage(named: local.foto)
            
            // Retornamos a célula
            return localCell
        }
        
        // Retornamos a célula mesmo que não tenha informação
        return cell
    }
    
}

// 5. Configurando o formato e tamanho das células
extension MenusViewController: UICollectionViewDelegateFlowLayout {
    // Defino a distancia entre os itens na CollectionView
    private var sectionInsets: UIEdgeInsets {
        return UIEdgeInsets(top: 10.0, left: 10.0, bottom: 20.0, right: 10.0)
    }
    
    // 1. Defina o tamanho a altura e largura de cada célula
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        // Distância da borda de cima e da borda de baixo
        let padding = (sectionInsets.top + sectionInsets.bottom) * 2
        let heightForItem = collectionView.frame.height - (padding * 2)
        let widthForItem = (heightForItem * 4) / 3
        
        return CGSize(width: widthForItem, height: heightForItem)
    }
    
    // 2. Define as distâncias entre as células na CollectionView
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return sectionInsets
    }
    
    // 3. Define o espaço entre linhas e colunas de células dentro de uma seção
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return sectionInsets.left
    }
    
}
