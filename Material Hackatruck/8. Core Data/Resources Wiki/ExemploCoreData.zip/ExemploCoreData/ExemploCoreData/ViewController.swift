//
//  ViewController.swift
//  ExemploCoreData
//
//  Created by Francini Roberta de Carvalho on 11/18/16.
//  Copyright © 2016 Francini Carvalho. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var app: Aplicativo?
    var listaApps: [Aplicativo]?
    
    
    // MARK: inserir
    @IBOutlet weak var nomeInserir: UITextField!
    
    @IBAction func inserirApp(_ sender: AnyObject) {
        app = Aplicativo()
        app?.nome = nomeInserir.text
        
        if AplicativoDAO.insert() {
            print("saved!")
        }
    }
    
    
    // MARK: alterar
    @IBOutlet weak var nomeAlterar: UITextField!
    
    @IBAction func buscarPrimeiroApp(_ sender: AnyObject) {
        listaApps = AplicativoDAO.searchAll()
        
        if listaApps!.count > 0 {
            app = listaApps?.first
            nomeAlterar.text = app?.nome
        }
    }
    
    @IBAction func gravarAlteracao(_ sender: AnyObject) {
        app?.nome = nomeAlterar.text
        CoreDataManager.saveContext()
    }
    
    // MARK: excluir
    
    @IBOutlet weak var nomeExcluir: UITextField!
    
    @IBAction func buscarUltimoApp(_ sender: AnyObject) {
        listaApps = AplicativoDAO.searchAll()
        
        if listaApps!.count > 0 {
            app = listaApps?.last
            nomeExcluir.text = app?.nome
        }
    }
    
    @IBAction func confirmarExclusao(_ sender: AnyObject) {
        if AplicativoDAO.delete(app: app!) {
            print("deleted!")
        }
    }
    
    
    // MARK: buscar
    
    @IBAction func buscarTodos(_ sender: AnyObject) {
        listaApps = AplicativoDAO.searchAll()
        
        if listaApps!.count > 0 {
            for item in listaApps! {
                print(item.nome!)
            }
        }
    }
    
    
}

