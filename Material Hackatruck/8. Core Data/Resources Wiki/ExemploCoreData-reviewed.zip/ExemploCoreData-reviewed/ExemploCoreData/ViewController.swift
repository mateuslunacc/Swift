//
//  ViewController.swift
//  ExemploCoreData
//
//  Created by Francini Roberta de Carvalho on 11/18/16.
//  Copyright © 2016 Francini Carvalho. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // Objeto "Aplicativo" que será utilizado nas operações
    var app: Aplicativo?
    // Array de "Aplicativo" para utilizar nas operações
    var listaApps: [Aplicativo]?
    
    
    // MARK: inserir
    @IBOutlet weak var nomeInserir: UITextField!
    
    @IBAction func inserirApp(_ sender: AnyObject) {
        app = Aplicativo()
        app?.nome = nomeInserir.text
        
        /*
        Para adicionar o relacionamento entre categoria e app:
 
        let categoria = Categoria()
        categoria.descricao = "Jogos"
        categoria.addToApps(app)
 
        app?.categoria = categoria
        */
        
        // Se o objeto for inserido com sucesso, mostramos uma mensagem no output
        if CoreDataManager.insert(app: app!) {
            print("saved!")
        }
    }
    
    
    // MARK: alterar
    @IBOutlet weak var nomeAlterar: UITextField!
    
    // Para alterar, primeiro buscamos a lista dos apps já cadastrados no banco para modificar um deles
    @IBAction func buscarPrimeiroApp(_ sender: AnyObject) {
        listaApps = AplicativoDAO.searchAll()
        
        if listaApps!.count > 0 {
            // neste caso, estamos pegando sempre o primeiro objeto da lista para alterar
            app = listaApps?.first
            nomeAlterar.text = app?.nome
        }
    }
    
    @IBAction func gravarAlteracao(_ sender: AnyObject) {
        app?.nome = nomeAlterar.text
        // para gravar a alteração basta chamar o método "saveContext()" que o CoreData já criou previamente quando criamos o projeto
        // este método salva qualquer modificação que esteja em memória para o banco de dados
        CoreDataManager.saveContext()
    }
    
    // MARK: excluir
    
    @IBOutlet weak var nomeExcluir: UITextField!
    
    @IBAction func buscarUltimoApp(_ sender: AnyObject) {
        listaApps = AplicativoDAO.searchAll()
        
        if listaApps!.count > 0 {
            // neste caso, estamos pegando sempre o último objeto da lista para deletar
            app = listaApps?.last
            nomeExcluir.text = app?.nome
        }
    }
    
    @IBAction func confirmarExclusao(_ sender: AnyObject) {
        if CoreDataManager.delete(app: app!) {
            print("deleted!")
            nomeExcluir.text = ""
        }
    }
    
    
    // MARK: buscar
    
    // buscar todos os registros
    @IBAction func buscarTodos(_ sender: AnyObject) {
        // este método retorna todos os aplicativos cadastrados no banco
        listaApps = AplicativoDAO.searchAll()
        
        // em uma lista, é sempre importante verificar se a mesma contem objetos antes de tentar acessá-los
        if listaApps!.count > 0 {
            for item in listaApps! {
                print(item.nome!)
            }
        }
    }
    
    // buscar por nome
    @IBOutlet weak var nomeFiltroBusca: UITextField!
    
    @IBAction func buscarPorNome(_ sender: Any) {
        if nomeFiltroBusca.text != "" {
            listaApps = AplicativoDAO.searchByName(appName: nomeFiltroBusca.text!)
            
            // em uma lista, é sempre importante verificar se a mesma contem objetos antes de tentar acessá-los
            if listaApps!.count > 0 {
                for item in listaApps! {
                    print(item.nome!)
                }
            } else {
                print("sua busca não retornou resultados")
            }
            
        }
        
       
    }
    
    
}

