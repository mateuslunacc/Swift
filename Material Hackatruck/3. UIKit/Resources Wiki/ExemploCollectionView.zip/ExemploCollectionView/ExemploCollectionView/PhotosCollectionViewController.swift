//
//  PhotosCollectionViewController.swift
//  ExemploCollectionView
//
//  Created by Tiago - Eldorado on 12/12/16.
//  Copyright © 2016 Tiago - Eldorado. All rights reserved.
//

import UIKit

class PhotosCollectionViewController: UICollectionViewController {
    
    // Nosso array com as informações que precisamos
    var locais = Local.getList()
    
    private struct Storyboard {
        // 1. Defina o identifier para sua célula no storyboard
        static let cellIdentifier = "LocalCellIdentifier"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 2. Comente ou apague a linha abaixo
        // Ela aparece caso você crie sua classe a partir de Cocoa Touch Class herdando de UICollectionViewController
        
        // Register cell classes
        // self.collectionView!.registerClass(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)
    }
    
    // MARK: UICollectionViewDataSource
    
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // 3. Defina o número de sessões na CollectionView
        return 1
    }
    
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // 4. Defina o número de itens que serão apresentados na CollectionView
        return locais.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        // 5. Pegue o protótipo da célula no storyboard para reutilizá-la
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: Storyboard.cellIdentifier, for: indexPath)
        
        // 6. Caso a célula possa ser convertida para o  tipo correto...
        if let imageCell = cell as? ImageCollectionViewCell {
            // 6.1 ...configure a célula com as informações correspondentes
            let local = locais[indexPath.row]
            imageCell.image = UIImage(named: local.foto)
        }
        
        return cell
    }
}

// 7. Configurando o formato e tamanho das células
extension PhotosCollectionViewController: UICollectionViewDelegateFlowLayout {
    
    // Lembre-se que em uma extension só podemos ter
    // propriedades computadas!
    
    // Defina a distancia entre os itens na CollectionView
    private var sectionInsets: UIEdgeInsets {
        return UIEdgeInsets(
            top: 10.0,
            left: 10.0,
            bottom: 20.0,
            right: 10.0
        )
    }
    
    // Defina o número de células que terá por linha
    private var itemsPerRow: CGFloat {
        return 2
    }
    
    // 1. Defina a altura e largura de cada célula
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let paddingSpace = sectionInsets.left * (itemsPerRow + 1)
        let availableWidth = view.frame.width - paddingSpace
        let widthPerItem = availableWidth / itemsPerRow
        
        return CGSize(width: widthPerItem, height: widthPerItem)
    }
    
    // 2. Define as distâncias entre as células na CollectionView
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return sectionInsets
    }
    
    // 3. Define o espaço entre linhas e colunas de células dentro de uma seção
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return sectionInsets.left
    }
}
