//
//  Local.swift
//  ExemploCollectionView
//
//  Created by Tiago - Eldorado on 12/12/16.
//  Copyright © 2016 Tiago - Eldorado. All rights reserved.
//

import Foundation

class Local {
    // Propriedades da classe
    let nome: String
    let foto: String
    
    // Inicializador da classe
    init(nome: String, foto: String) {
        self.nome = nome
        self.foto = foto
    }
    
    // Retorna uma lista de locais para podermos utilizar na aplicação
    // As imagens estão no Assets.xcassets
    static func getList() -> [Local] {
        return [
            Local(nome: "Canela", foto: "cachoeira_caracol"),
            Local(nome: "Canela", foto: "catedral_canela"),
            Local(nome: "Gramado", foto: "centro_gramado"),
            Local(nome: "Canela", foto: "parque_caracol"),
            Local(nome: "Gramado", foto: "portal_gramado")
        ]
    }
}
