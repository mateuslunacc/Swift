//
//  AzulViewController.swift
//  ExemploStoryboard
//
//  Created by Francini Roberta de Carvalho on 12/5/16.
//  Copyright © 2016 Francini Carvalho. All rights reserved.
//

import UIKit

class AzulViewController: UIViewController {

    // outlet para o TextField do qual queremos obter o valor informado
    @IBOutlet weak var corTextField: UITextField!
    
    

    // MARK: - Navigation

    // método executado sempre que uma segue é disparada
    // qualquer ação que precise ocorrer antes da transição das views deve ser implementada aqui
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        // validação do identifier da segue, para saber qual segue está sendo executada
        if segue.identifier == "novaCorSegue" {
            
            // obtendo uma instância da nova viewController que será exibida
            if let novaView = segue.destination as? NovaCorViewController {
                
                // NÃO FUNCIONA!
                // não é possível acessar um outlet a partir de outra classe que não seja a que ele está declarado
                // novaView.corLabel.text = corTextField.text
                
                // enviando o texto digitado pelo usuário para o objeto "cor" existente na view seguinte  
                novaView.cor = corTextField.text
            }
        }
    }


}
