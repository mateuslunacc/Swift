//
//  MusicaTableViewCell.swift
//  RevisaoSemana1
//
//  Created by Francini Roberta de Carvalho on 12/12/16.
//  Copyright © 2016 Francini Carvalho. All rights reserved.
//

import UIKit

class MusicaTableViewCell: UITableViewCell {

    @IBOutlet weak var infoMusicaLabel: UILabel!
    @IBOutlet weak var artistaLabel: UILabel!
    
    
}
