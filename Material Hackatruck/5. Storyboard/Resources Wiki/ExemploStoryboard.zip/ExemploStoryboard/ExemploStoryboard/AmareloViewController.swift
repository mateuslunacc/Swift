//
//  AmareloViewController.swift
//  ExemploStoryboard
//
//  Created by Francini Roberta de Carvalho on 12/5/16.
//  Copyright © 2016 Francini Carvalho. All rights reserved.
//

import UIKit

class AmareloViewController: UIViewController {

    /*
     método necessário para a ação de voltar para esta view
     não é necessário implementar conteúdo para que a ação ocorra
     para "chamar" este método: a partir da view que deve ser desempilhada para exibir esta, clicar no botão pressionando "control" e arrastar até o botão "exit" na tela
     */
    @IBAction func voltar(segue: UIStoryboardSegue) {
        
    }

}
