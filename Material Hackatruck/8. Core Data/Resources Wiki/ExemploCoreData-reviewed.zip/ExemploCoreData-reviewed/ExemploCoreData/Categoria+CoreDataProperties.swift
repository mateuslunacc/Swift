//
//  Categoria+CoreDataProperties.swift
//  ExemploCoreData
//
//  Created by Francini Roberta de Carvalho on 12/13/16.
//  Copyright © 2016 Francini Carvalho. All rights reserved.
//

import Foundation
import CoreData
 

extension Categoria {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Categoria> {
        return NSFetchRequest<Categoria>(entityName: "Categoria");
    }

    @NSManaged public var descricao: String?
    @NSManaged public var apps: NSSet?

}

// MARK: Generated accessors for apps
extension Categoria {

    @objc(addAppsObject:)
    @NSManaged public func addToApps(_ value: Aplicativo)

    @objc(removeAppsObject:)
    @NSManaged public func removeFromApps(_ value: Aplicativo)

    @objc(addApps:)
    @NSManaged public func addToApps(_ values: NSSet)

    @objc(removeApps:)
    @NSManaged public func removeFromApps(_ values: NSSet)

}
