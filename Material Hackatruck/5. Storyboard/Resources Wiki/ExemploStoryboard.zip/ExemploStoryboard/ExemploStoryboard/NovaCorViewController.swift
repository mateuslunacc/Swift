//
//  NovaCorViewController.swift
//  ExemploStoryboard
//
//  Created by Francini Roberta de Carvalho on 12/5/16.
//  Copyright © 2016 Francini Carvalho. All rights reserved.
//

import UIKit

class NovaCorViewController: UIViewController {

    // outlet do label que preencheremos
    @IBOutlet weak var corLabel: UILabel!
    
    // objeto que recebe o texto da view anterior
    var cor: String?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        corLabel.text = cor
        
        
        if cor != nil {
            
            // se a cor tiver um valor, testaremos se é uma das 3 cores abaixo; se não for nenhuma deles, o padrão de cor utilizado é o cinza
            switch cor!.lowercased() {
                case "verde":
                    self.view.backgroundColor = UIColor.green
                
                case "rosa":
                    self.view.backgroundColor = UIColor.magenta
                    
                case "roxo":
                    self.view.backgroundColor = UIColor.purple
                    
                default:
                    self.view.backgroundColor = UIColor.gray
                }
        }
    }

    

}
