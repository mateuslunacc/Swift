//
//  ImageCollectionViewCell.swift
//  ExemploCollectionView
//
//  Created by Tiago - Eldorado on 12/12/16.
//  Copyright © 2016 Tiago - Eldorado. All rights reserved.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    // Outlet para a ImageView onde mostramos a imagem
    @IBOutlet weak var cellImageView: UIImageView!
    
    var image: UIImage? {
        get {
            return cellImageView.image
        }
        
        set {
            cellImageView?.image = newValue
        }
    }

}
