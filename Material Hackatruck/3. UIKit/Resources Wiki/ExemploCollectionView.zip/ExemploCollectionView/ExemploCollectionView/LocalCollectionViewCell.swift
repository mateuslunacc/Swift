//
//  LocalCollectionViewCell.swift
//  ExemploCollectionView
//
//  Created by Tiago - Eldorado on 12/12/16.
//  Copyright © 2016 Tiago - Eldorado. All rights reserved.
//

import UIKit

class LocalCollectionViewCell: UICollectionViewCell {
    
    // 1. Outlets para os componentes na célula
    @IBOutlet weak var localImageView: UIImageView!
    @IBOutlet weak var nomeDoLocalLabel: UILabel!
    
    // 2. Informação a ser mostrada na célula
    var local: Local? {
        didSet {
            if let local = self.local {
                nomeDoLocalLabel?.text = local.nome
                localPicture = UIImage(named: local.nome)
            }
        }
    }
    
    var localPicture: UIImage? {
        get {
            return localImageView.image
        }
        
        set {
            localImageView?.image = newValue
        }
    }
    
}
