//
//  ListaMusicasTableViewController.swift
//  RevisaoSemana1
//
//  Created by Francini Roberta de Carvalho on 12/12/16.
//  Copyright © 2016 Francini Carvalho. All rights reserved.
//

import UIKit

class ListaMusicasTableViewController: UITableViewController {

    var listaMusicas: [Musica]?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let musica1 = Musica(nome: "Master of Puppets", artista: "Metallica", nomeAlbum: "Master of Puppets", capaAlbum: "master")
        let musica2 = Musica(nome: "Back in Black", artista: "AC/DC", nomeAlbum: "Back in Black", capaAlbum: "acdc")
        let musica3 = Musica(nome: "Jeremy", artista: "Pearl Jam", nomeAlbum: "Ten", capaAlbum: "ten")
        
        listaMusicas = [Musica]()
        listaMusicas?.append(musica1)
        listaMusicas?.append(musica2)
        listaMusicas?.append(musica3)
        
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

   
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listaMusicas!.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MusicaCell", for: indexPath) as! MusicaTableViewCell

        cell.infoMusicaLabel.text = listaMusicas?[indexPath.row].nome
        cell.artistaLabel.text = listaMusicas?[indexPath.row].artista

        return cell
    }
    

    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    

    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        if segue.identifier == "mostrarDetalhesSegue" {
            if let novaView = segue.destination as? DetalhesViewController {
                novaView.musica = listaMusicas![(tableView.indexPathForSelectedRow?.row)!]
            }
        }
    }
    

}
