//
//  Categoria+CoreDataClass.swift
//  ExemploCoreData
//
//  Created by Francini Roberta de Carvalho on 12/13/16.
//  Copyright © 2016 Francini Carvalho. All rights reserved.
//

import Foundation
import CoreData


public class Categoria: NSManagedObject {

    convenience init() {
        let context = CoreDataManager.getContext()
        let entity = NSEntityDescription.entity(forEntityName: "Categoria", in: context)
        
        self.init(entity: entity!, insertInto: context)
    }
}
