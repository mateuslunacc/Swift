//
//  AppDAO.swift
//  ExemploCoreData
//
//  Created by Francini Roberta de Carvalho on 11/18/16.
//  Copyright © 2016 Francini Carvalho. All rights reserved.
//

import Foundation
import CoreData

class AplicativoDAO {
    
    
    static func searchAll() -> [Aplicativo] {
        // lista de apps que será retornada pelo método
        var apps = [Aplicativo]()
        // objeto request que será enviado para o banco, com todas as configurações da busca que será executada
        // ele usa o fetchRequest() que é inserido na classe gerada pelo CoreData
        let request: NSFetchRequest<Aplicativo> = Aplicativo.fetchRequest()
        // configuração de ordenação dos dados: serão ordenados pelo campo "nome" em ordem crescente
        request.sortDescriptors = [NSSortDescriptor.init(key: "nome", ascending: true)]
        
        
        do {
            // executando a busca no banco
            try apps = CoreDataManager.getContext().fetch(request) 
            print("Total de apps cadastrados = ", apps.count)
            
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }
        
        return apps
    }
    
    static func searchByName(appName: String) -> [Aplicativo] {
        // lista de apps que será retornada pelo método
        var apps = [Aplicativo]()
        // objeto request que será enviado para o banco, com todas as configurações da busca que será executada
        // ele usa o fetchRequest() que é inserido na classe gerada pelo CoreData
        let request: NSFetchRequest<Aplicativo> = Aplicativo.fetchRequest()
        // montando o filtro da busca: todos os apps que contiverem a string informada
        let predicate = NSPredicate(format: "nome contains[c] %@", appName)
        request.predicate = predicate
        // configuração de ordenação dos dados: serão ordenados pelo campo "nome" em ordem crescente
        request.sortDescriptors = [NSSortDescriptor.init(key: "nome", ascending: true)]
        
        
        do {
            // executando a busca no banco
            try apps = CoreDataManager.getContext().fetch(request)
            print("Total de apps por nome = ", apps.count)
            
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }
        
        return apps
    }
    
}
