//
//  Aplicativo+CoreDataProperties.swift
//  ExemploCoreData
//
//  Created by Francini Roberta de Carvalho on 12/13/16.
//  Copyright © 2016 Francini Carvalho. All rights reserved.
//

import Foundation
import CoreData
 

extension Aplicativo {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Aplicativo> {
        return NSFetchRequest<Aplicativo>(entityName: "Aplicativo");
    }

    @NSManaged public var nome: String?
    @NSManaged public var categoria: Categoria?

}
