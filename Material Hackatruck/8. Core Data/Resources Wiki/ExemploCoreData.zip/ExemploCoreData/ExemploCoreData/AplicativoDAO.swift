//
//  AppDAO.swift
//  ExemploCoreData
//
//  Created by Francini Roberta de Carvalho on 11/18/16.
//  Copyright © 2016 Francini Carvalho. All rights reserved.
//

import Foundation
import CoreData

class AplicativoDAO {
    
    static func insert() -> Bool {
        var result = false
                
        do {
            try CoreDataManager.getContext().save()
            result = true
                        
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }
        
        return result
    }

    static func delete(app: Aplicativo) -> Bool {
        var result = false
        
        CoreDataManager.getContext().delete(app)
        
        do {
            try CoreDataManager.getContext().save()
            result = true
                        
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }
        
        return result
    }
    
    static func searchAll() -> [Aplicativo] {
        var apps = [Aplicativo]()
        let request: NSFetchRequest<Aplicativo> = Aplicativo.fetchRequest()
        request.sortDescriptors = [NSSortDescriptor.init(key: "nome", ascending: true)]
        
        
        do {
            try apps = CoreDataManager.getContext().fetch(request) 
            print("Total de apps cadastrados = ", apps.count)
            
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }
        
        return apps
    }
    
    
}
