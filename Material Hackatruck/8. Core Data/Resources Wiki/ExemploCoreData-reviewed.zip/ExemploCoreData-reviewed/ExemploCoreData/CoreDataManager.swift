//
//  CoreDataManager.swift
//  ExemploCoreData
//
//  Created by Francini Roberta de Carvalho on 11/18/16.
//  Copyright © 2016 Francini Carvalho. All rights reserved.
//

import Foundation
import CoreData

class CoreDataManager {
    
    // MARK: - Core Data stack
    
    static var persistentContainer: NSPersistentContainer = {
        /*
         The persistent container for the application. This implementation
         creates and returns a container, having loaded the store for the
         application to it. This property is optional since there are legitimate
         error conditions that could cause the creation of the store to fail.
         */
        let container = NSPersistentContainer(name: "ExemploCoreData")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                
                /*
                 Typical reasons for an error here include:
                 * The parent directory does not exist, cannot be created, or disallows writing.
                 * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                 * The device is out of space.
                 * The store could not be migrated to the current model version.
                 Check the error message to determine what the actual problem was.
                 */
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    // MARK: - Core Data Saving support
    
    class func saveContext () {
        let context = persistentContainer.viewContext
        
        if context.hasChanges {
            do {
                try context.save()
                print("context updated")
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    // Retorna o contexto de banco de dados com o qual estamos trabalhando
    // O contexto é como uma cópia do banco em memória, todas as alterações são realizadas no contexto e depois salvas no banco de dados.
    static func getContext () -> NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    // Método genérico para inserir objetos no banco
    static func insert(app: NSManagedObject) -> Bool {
        var result = false
        
        // Preparando o banco para inserir o novo objeto
        CoreDataManager.getContext().insert(app)
        
        do {
            // Salvando o contenxto, ou seja, gravando no banco definitivamente as alterações realizadas
            // Qualquer tipo de alteração é gravada no banco quando o método save() é executado, independente de que tipo de alteração tenha sido feita
            try CoreDataManager.getContext().save()
            result = true
            
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }
        
        return result
    }
    
    // Método genérico para deletar objetos do banco
    static func delete(app: NSManagedObject) -> Bool {
        var result = false
        
        // Preparando o banco para deletar o novo objeto
        CoreDataManager.getContext().delete(app)
        
        do {
            // Salvando o contenxto, ou seja, gravando no banco definitivamente as alterações realizadas
            try CoreDataManager.getContext().save()
            result = true
            
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }
        
        return result
    }
    
    
    
}
