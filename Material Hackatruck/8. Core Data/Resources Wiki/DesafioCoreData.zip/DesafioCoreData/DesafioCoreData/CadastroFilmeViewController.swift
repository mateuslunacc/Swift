//
//  CadastroFilmeViewController.swift
//  DesafioCoreData
//
//  Created by Francini Roberta de Carvalho on 11/1/16.
//  Copyright © 2016 Francini Carvalho. All rights reserved.
//

import UIKit

// Controller da view de cadastro de filmes, acionada pelo botão "+"
class CadastroFilmeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


}
